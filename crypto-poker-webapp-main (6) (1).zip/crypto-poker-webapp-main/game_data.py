# game_data.py
from typing import Dict, List

# Куда кладём игроков при join
seat_map: Dict[int, List[int]] = {}
